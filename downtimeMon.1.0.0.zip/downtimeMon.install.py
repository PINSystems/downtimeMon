import os
import shutil
import subprocess
import sys
import time 

installDir = '/etc/downtimeMon'
result=False


#----------------------------------------------------
# --- Utility Methods
#----------------------------------------------------

def createDir(dirPath):
    if not os.path.exists(dirPath):
        try:
            os.mkdir(dirPath)
            print(f"Directory '{dirPath}' created successfully.")
        except FileExistsError:
            print(f"Directory '{dirPath}' already exists.")
        except PermissionError:
            print(f"Permission denied: Unable to create directory '{dirPath}'.")
            return False
        except Exception as e:
            print(f"An error occurred creating directory '{dirPath}': \n{e}")
            return False
    return True


def copyFile(src, dst):
    try:
        shutil.copy2(src, dst)
        print(f"'{src}' successfully copied to '{dst}'")
    except PermissionError:
        print(f"Permission denied: Unable to copy '{src}' to '{dst}'.")
        return False
    except Exception as e:
        print(f"An error occurred copying '{src}' to '{dst}': \n{e}")
        return False
    return True


#----------------------------------------------------
# --- Stop the service
#----------------------------------------------------

# sudo systemctl stop downtimeMon
subprocess.run(["sudo", "systemctl", "stop", "downtimeMon"]) 
subprocess.run(["sudo", "systemctl", "stop", "downtimeMonServer"]) 


#----------------------------------------------------
# --- Create the reqiuired directories
#----------------------------------------------------

result = createDir(installDir)
if not result:
    sys.exit('Aborting install!')

result = createDir(installDir + '/logs')
if not result:
    sys.exit('Aborting install!')


#----------------------------------------------------
# --- Remove prior version files
#----------------------------------------------------
for filename in os.listdir(installDir):
   file_path = os.path.join(installDir, filename)
   if os.path.isfile(file_path):
      os.remove(file_path)


#----------------------------------------------------
# --- Copy the required files
#----------------------------------------------------

result = copyFile('./downtimeMon.info.txt', installDir + '/downtimeMon.info.txt')
if not result:
    sys.exit('Aborting install!')

result = copyFile('./downtimeMon.py', installDir + '/downtimeMon.py')
if not result:
    sys.exit('Aborting install!')

result = copyFile('./downtimeMon.service', '/etc/systemd/system/downtimeMon.service')
if not result:
    sys.exit('Aborting install!')

result = copyFile('./downtimeMonServer.py', installDir + '/downtimeMonServer.py')
if not result:
    sys.exit('Aborting install!')

result = copyFile('./downtimeMonServer.service', '/etc/systemd/system/downtimeMonServer.service')
if not result:
    sys.exit('Aborting install!')


#----------------------------------------------------
# --- Start the services
#----------------------------------------------------

# --- Update systemd internal data
subprocess.run(["sudo", "systemctl", "daemon-reload"]) 

# --- Enable the MONITOR service
subprocess.run(["sudo", "systemctl", "enable", "downtimeMon.service"]) 

# --- Start the MONITOR service
subprocess.run(["sudo", "systemctl", "start", "downtimeMon.service"]) 

# --- Enable the SERVER service
subprocess.run(["sudo", "systemctl", "enable", "downtimeMonServer.service"]) 

# --- Start the SERVER service
subprocess.run(["sudo", "systemctl", "start", "downtimeMonServer.service"]) 


#----------------------------------------------------
# We're done!
#----------------------------------------------------

print(f"\nInstallation complete. \nRetrieving service status...\n")

time.sleep(3)
subprocess.run(["sudo", "systemctl", "status", "downtimeMon.service"])
subprocess.run(["sudo", "systemctl", "status", "downtimeMonServer.service"])
