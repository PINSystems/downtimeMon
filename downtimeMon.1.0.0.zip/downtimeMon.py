from collections import deque
from datetime import datetime, timezone, timedelta
import os
#import psutil
import time

#--------------------------------------------------------------------------
# --- CONFIGURATION
#--------------------------------------------------------------------------

scriptDir = os.path.dirname(os.path.abspath(__file__))

lastExecutionFile = scriptDir + '/lastExecution'
executionLogFile =  scriptDir + '/logs/executions.log'
downtimeLogFile = scriptDir + '/logs/downtime.log' 

interval = 300                                # Execute every n seconds

# Store the last 24 hours of exection timestamps
executionLogLen = int((24 * 3600)/interval)

dtMonVer = '1.0.0'
print(f'Launching downtimeMon (v' + dtMonVer +')... \n   Execution Directory: "{scriptDir}" \n   interval seconds: ' + str(interval) )



#--------------------------------------------------------------------------
# --- METHODS
#--------------------------------------------------------------------------

#def script_is_running(scriptPath):
#    for q in psutil.process_iter():
#        if q.name().startswith('python'):
#            if len(q.cmdline()) > 1 and scriptPath in q.cmdline() and q.pid != os.getpid():
#                print(f"'{scriptPath}' Process is already running")
#                return True
#    return False


def check_for_downtime(executionTs):
    lastExecContent = '';
    if os.path.exists(lastExecutionFile):
        with open(lastExecutionFile, 'r') as f:
            lastExecContent = f.read()
            if len(lastExecContent.strip()) > 0:
                lsc = datetime.fromisoformat(lastExecContent.strip())
                lsc.replace(tzinfo=timezone.utc)
                if lsc + timedelta(seconds=(interval + 2)) < executionTs:
                    return True, lsc
    return False, None

        
def log_downtime(lastStatusTs):
    currTs = datetime.now(timezone.utc)
    diff = currTs - lastStatusTs
    logVal = '{ "currentTimestamp":"' + datetime.isoformat(currTs) + '", "lastExecutionFileEntry":"' + datetime.isoformat(lastStatusTs) + '", "down_hours":' + format(diff.total_seconds()/3600, '.2f')  + ', "down_minutes":' + format(diff.total_seconds()/60, '.2f') + ', "test_interval_secs":' + str(interval) + '}'
    with open(downtimeLogFile, 'a') as f:
        f.write(logVal + "\n")


def log_execution(executionTs):
    try:
        if os.path.exists(executionLogFile):
            with open(executionLogFile, 'r') as f:
                # Use deque with maxlen to efficiently store only the last n lines
                last_lines = deque(f, maxlen=executionLogLen-1)

            # Overwrite the original file with the retained lines
            with open(executionLogFile, 'w') as f:
                for line in last_lines:
                    f.write(line)

        if os.path.exists(executionLogFile):
            with open(executionLogFile, 'a') as f:
                f.write(datetime.isoformat(executionTs) + "\n")
        else:
            with open(executionLogFile, 'w') as f:
                f.write(datetime.isoformat(executionTs) + "\n")

    except FileNotFoundError:
        print(f"Error: File not found at {executionLogFile}")
    except Exception as e:
        print(f"An error occurred: {e}")

    
def store_ExecutionTs(executionTs):   
    # Delete the file, if existing   
    #if os.path.exists(lastExecutionFile):
    #    os.remove(lastExecutionFile)
    with open(lastExecutionFile, 'w') as f:
        f.write(executionTs.isoformat())    


#--------------------------------------------------------------------------
# --- MAIN LOGIC
#--------------------------------------------------------------------------

#if script_is_running(scriptDir + '/downtimeMon.py'):
#    sys.exit('Aborting startup... Already running')

while True:
    currTs = datetime.now(timezone.utc)    
    downtime, lastExecutionTs = check_for_downtime(currTs)
    if downtime == True:
        log_downtime(lastExecutionTs)
    store_ExecutionTs(currTs)
    log_execution(currTs)
    nextExec =  currTs + timedelta(seconds=interval)
    sleepSecs = (nextExec - datetime.now(timezone.utc)).total_seconds()
    #print(f"   sleepSecs: {str(sleepSecs)}")
    if sleepSecs > 0:
        time.sleep(sleepSecs)
	
